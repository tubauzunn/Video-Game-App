import Foundation

struct PlatformResponse: Codable {
    let results: [Platform]
}

struct Platform: Codable {
    let id: Int
    let name: String
    let slug: String
    let background_image: String?
  
}

