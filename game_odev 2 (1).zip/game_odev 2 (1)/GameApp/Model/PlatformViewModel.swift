import Foundation

protocol PlatformViewModelDelegate: AnyObject {
    func platformsDidUpdate()
}

class PlatformViewModel {
    private(set) var platforms: [Platform] = []
    private var filteredPlatforms: [Platform] = []
    weak var delegate: PlatformViewModelDelegate?
    
    func fetchPlatforms() {
        guard let url = URL(string: "https://api.rawg.io/api/games?key=edff8eaf0d3b4de29529ae6a46183275") else { return }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    let platformResponse = try JSONDecoder().decode(PlatformResponse.self, from: data)
                    self.platforms = platformResponse.results
                    DispatchQueue.main.async {
                        self.delegate?.platformsDidUpdate()
                    }
                } catch {
                    print("Error decoding data: \(error)")
                }
            } else if let error = error {
                print("Error fetching data: \(error)")
            }
        }.resume()
    }
    func filterPlatforms(with searchText: String) {
            if searchText.isEmpty {
                filteredPlatforms = platforms
            } else {
                // searchText ile filtreleme işlemleri
                filteredPlatforms = platforms.filter { $0.name.lowercased().contains(searchText.lowercased()) }
            }
            delegate?.platformsDidUpdate()
        }

}
