import UIKit

class DetailViewController: UIViewController {
    
    var platform: Platform?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Detay sayfasının tasarımı ve içeriği buraya eklenir
        if let platform = platform {
            // Örnek olarak, platformun ismini ekrana yazdırabiliriz
            let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
            label.text = platform.name
            label.center = view.center
            view.addSubview(label)
        }
    }
}
