import Foundation

// PlatformViewModelDelegate protokolü, platform verilerinin güncellendiğini bildirmek için kullanılır.
protocol PlatformViewModelDelegate: AnyObject {
    // platformsDidUpdate() yöntemi, platform verilerinin güncellendiğinde çağrılır.
    func platformsDidUpdate()
}

