import UIKit

class PlatformListViewController: UIViewController {
    
    private let viewModel = PlatformViewModel()
    private let tableView = UITableView()
    private let searchBar = UISearchBar()
    private let collectionView: UICollectionView
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .themeBackground
        setupSearchBar()
        setupCollectionView()
        setupTableView()
        viewModel.delegate = self
        viewModel.fetchPlatforms()
        title = "Games"
    }
    
    private func setupSearchBar() {
            searchBar.delegate = self
            searchBar.placeholder = "Search Games"
            searchBar.sizeToFit()
            view.addSubview(searchBar)
            searchBar.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                searchBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            ])
        }
    
    private func setupCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(PlatformImageCell.self, forCellWithReuseIdentifier: "ImageCell")
        collectionView.backgroundColor = .themeBackground
        collectionView.isPagingEnabled = true
        
        view.addSubview(collectionView)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: searchBar.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.heightAnchor.constraint(equalToConstant: 300)
        ])
    }
    
    private func setupTableView() {
        view.addSubview(tableView)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(PlatformCell.self, forCellReuseIdentifier: "PlatformCell")
        tableView.backgroundColor = .themeBackground
        tableView.separatorStyle = .none
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: collectionView.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
}



extension PlatformListViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.filterPlatforms(with: searchText) // Bu satırı değiştirin
    }
}




extension PlatformListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.platforms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlatformCell", for: indexPath) as! PlatformCell
        let platform = viewModel.platforms[indexPath.row]
        cell.configure(with: platform)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let platform = viewModel.platforms[indexPath.row]
        let detailVC = PlatformDetailViewController(platform: platform)
        navigationController?.pushViewController(detailVC, animated: true)
    }
}

extension PlatformListViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return min(viewModel.platforms.count, 3)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath) as! PlatformImageCell
        let platform = viewModel.platforms[indexPath.item]
        
        if let urlString = platform.background_image, let url = URL(string: urlString) {
            cell.imageView.image = nil
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url) {
                    DispatchQueue.main.async {
                        cell.imageView.image = UIImage(data: data)
                    }
                }
            }
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
}

extension PlatformListViewController: PlatformViewModelDelegate {
    func platformsDidUpdate() {
        tableView.reloadData()
        collectionView.reloadData()
    }
}

class PlatformImageCell: UICollectionViewCell {
    let imageView = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class PlatformCell: UITableViewCell {
    private let nameLabel = UILabel()
    private let slugLabel = UILabel()
    private let platformImageView = UIImageView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        selectionStyle = .none
        backgroundColor = .clear
        
        platformImageView.contentMode = .scaleAspectFit
        platformImageView.clipsToBounds = true
        platformImageView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(platformImageView)
        
        nameLabel.font = .themeTitleFont
        nameLabel.textColor = .themeText
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(nameLabel)
        
        slugLabel.font = .themeSubtitleFont
        slugLabel.textColor = .themeText
        slugLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(slugLabel)
        
        NSLayoutConstraint.activate([
            platformImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            platformImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            platformImageView.widthAnchor.constraint(equalToConstant: 80),
            platformImageView.heightAnchor.constraint(equalToConstant: 80),
            
            nameLabel.leadingAnchor.constraint(equalTo: platformImageView.trailingAnchor, constant: 10),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            
            slugLabel.leadingAnchor.constraint(equalTo: platformImageView.trailingAnchor, constant: 10),
            slugLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 5),
            slugLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            slugLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }
    
    func configure(with platform: Platform) {
        nameLabel.text = platform.name
        slugLabel.text = platform.slug
        
        if let urlString = platform.background_image, let url = URL(string: urlString) {
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url) {
                    DispatchQueue.main.async {
                        self.platformImageView.image = UIImage(data: data)
                    }
                }
            }
        } else {
            platformImageView.image = nil
        }
    }
}
