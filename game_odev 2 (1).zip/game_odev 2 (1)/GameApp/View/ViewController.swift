import UIKit

struct PlatformResponse: Codable {
    let results: [Platform]
}

struct Platform: Codable {
    let id: Int
    let name: String
    let slug: String
    let background_image: String?
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var platforms: [Platform] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        
        fetchPlatforms()
    }
    
    func fetchPlatforms() {
        guard let url = URL(string: "https://api.rawg.io/api/games?key=edff8eaf0d3b4de29529ae6a46183275") else { return }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    let platformResponse = try JSONDecoder().decode(PlatformResponse.self, from: data)
                    DispatchQueue.main.async {
                        self.platforms = platformResponse.results
                        self.tableView.reloadData()
                    }
                } catch {
                    print("Error decoding data: \(error)")
                }
            } else if let error = error {
                print("Error fetching data: \(error)")
            }
        }.resume()
    }
    
    // MARK: - UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return platforms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath)
        let platform = platforms[indexPath.row]
        cell.textLabel?.text = platform.name
        cell.detailTextLabel?.text = platform.slug
        
        if let urlString = platform.background_image, let url = URL(string: urlString) {
            let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 80, height: 80))
            imageView.contentMode = .scaleAspectFit
            imageView.clipsToBounds = true
            cell.accessoryView = imageView
            
            // Resmi yükleme
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url) {
                    DispatchQueue.main.async {
                        imageView.image = UIImage(data: data)
                    }
                }
            }
        } else {
            cell.accessoryView = nil
        }
        
        return cell
    }
}
