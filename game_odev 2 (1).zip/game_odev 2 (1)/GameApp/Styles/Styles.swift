import UIKit

extension UIColor {
    static let themeBackground = UIColor(named: "themeBackground") ?? UIColor.systemBackground
    static let themePrimary = UIColor(named: "themePrimary") ?? UIColor.black
    static let themeText = UIColor(named: "themeText") ?? UIColor.label
}

extension UIFont {
    static let themeTitleFont = UIFont.systemFont(ofSize: 24, weight: .bold)
    static let themeSubtitleFont = UIFont.systemFont(ofSize: 16, weight: .medium)
    static let themeBodyFont = UIFont.systemFont(ofSize: 14, weight: .regular)
}
